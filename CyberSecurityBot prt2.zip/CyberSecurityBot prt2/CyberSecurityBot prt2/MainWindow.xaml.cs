﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Media;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace CyberSecurityBot_Part2
{
    public partial class MainWindow : Window
    {
        // Memory 
        private string userName = "";
        private string favouriteTopic = "";
        private string lastTopic = "";
        private bool waitingForName = true;

        // Random response lists 
        private static readonly Random rng = new Random();

        private List<string> phishingTips = new List<string>
        {
            "Be cautious of emails asking for personal info. Scammers disguise themselves as trusted organisations.",
            "Never click links in suspicious emails — go directly to the official website instead.",
            "Check the sender's email address carefully for small typos (e.g. suppport@bank.co.za).",
            "Legitimate organisations will NEVER ask for your PIN or OTP via email.",
            "Look for urgent language like 'Your account will be suspended!' — a classic phishing trick."
        };

        private List<string> passwordTips = new List<string>
        {
            "Use at least 12 characters combining letters, numbers, and symbols.",
            "Never reuse the same password on different websites.",
            "Use a password manager like Bitwarden to store unique passwords safely.",
            "Never share your password with anyone, even 'IT support'.",
            "Change your password immediately if a site you use gets hacked."
        };

        private List<string> privacyTips = new List<string>
        {
            "Review the privacy settings on all your social media accounts regularly.",
            "Limit the personal information you share publicly online.",
            "Use a VPN when connecting to public Wi-Fi to protect your data.",
            "Read app permissions before installing — does that app really need your contacts?",
            "Enable two-factor authentication on every account that supports it."
        };

        // Sentiment word lists
        private List<string> worriedWords = new List<string> { "worried", "scared", "afraid", "nervous", "anxious", "fear" };
        private List<string> frustratedWords = new List<string> { "frustrated", "angry", "annoyed", "confused", "dont understand", "don't understand" };
        private List<string> curiousWords = new List<string> { "curious", "interested", "want to know", "how does", "what is", "explain" };

        // Constructor 
        public MainWindow()
        {
            InitializeComponent();
            Loaded += (s, e) => StartUp();
        }

        private async void StartUp()
        {
            PlayGreeting();
            await Task.Delay(400);
            AddBotMessage("   ╔════════════════════════════╗\n      ║  CyberSecurity Bot (CSAB)  ║\n      ║  Your Security, OUR Passion ║\n      ╚════════════════════════════╝");
            await Task.Delay(300);
            AddBotMessage("Hi there! Welcome to the Cybersecurity Awareness Bot.\n\nWhat is your name?");
        }

        // handles main input
        private string GetResponse(string raw)
        {
            string input = raw.ToLower().Trim();

            // Capture name on first message
            if (waitingForName)
            {
                userName = raw.Trim();
                waitingForName = false;
                return $"Great to meet you, {userName}! \n\nI'm here to help you stay safe online.\n\n Type 'topics' to see what I can help with!";
            }

            // Detect sentiment and build a prefix
            string prefix = GetSentimentPrefix(input);

            // Exit detector and response
            if (input == "exit" || input == "quit" || input == "bye" || input=="okay, thank")
                return $"Goodbye, {userName}! Stay safe online — think before you click!";

            // Follow-up respones
            if (input.Contains("more") || input.Contains("another tip") || input.Contains("tell me more") || input.Contains("keep going"))
                return prefix + GetFollowUp();

            // General questions
            if (input.Contains("how are you"))
                return prefix + $"I'm doing great, {userName}! Ready to help you stay cyber-safe!";

            if (input.Contains("who are you") || input.Contains("your purpose"))
                return prefix + "I educate South African citizens about cybersecurity threats like phishing, malware, and unsafe browsing. ";

            if (input.Contains("topics") || input.Contains("help") || input.Contains("menu"))
                return GetTopicsMenu();

            // Memory
            if (input.Contains("interested in"))
            {
                int idx = input.IndexOf("interested in") + "interested in".Length;
                favouriteTopic = raw.Substring(idx).Trim().TrimEnd('.');
                lastTopic = favouriteTopic.ToLower();
                return $"Got it! I'll remember you're interested in **{favouriteTopic}**. \n\nWould you like a tip about it now?";
            }

            // Recognizing key words
            if (input.Contains("password")) { lastTopic = "password"; return prefix + GetRandom(passwordTips); }
            if (input.Contains("phishing") || input.Contains("scam") || input.Contains("email fraud"))
            { lastTopic = "phishing"; return prefix + GetRandom(phishingTips); }
            if (input.Contains("privacy")) { lastTopic = "privacy"; return prefix + Personalise(GetRandom(privacyTips)); }
            if (input.Contains("browsing") || input.Contains("website") || input.Contains("internet"))
            { lastTopic = "browsing"; return prefix + BrowsingTips(); }
            if (input.Contains("malware") || input.Contains("virus"))
            { lastTopic = "malware"; return prefix + MalwareTips(); }
            if (input.Contains("social engineering") || input.Contains("vishing") || input.Contains("smishing"))
            { lastTopic = "social engineering"; return prefix + SocialEngineeringTips(); }
            if (input.Contains("2fa") || input.Contains("two factor") || input.Contains("authentication"))
            { lastTopic = "2fa"; return prefix + TwoFATips(); }

            // Error handling
            return "I'm not sure I understand that. Could you rephrase?\n\nTry typing 'topics' to see what I can help with!";
        }

        //  Sentiment detection 
        private string GetSentimentPrefix(string input)
        {
            foreach (var w in worriedWords)
                if (input.Contains(w))
                    return "It's completely understandable to feel that way. Scammers can be very convincing. Let me share some tips to help.\n\n";

            foreach (var w in frustratedWords)
                if (input.Contains(w))
                    return "I hear you — cybersecurity can feel overwhelming. Let me break it down simply. \n\n";

            foreach (var w in curiousWords)
                if (input.Contains(w))
                    return "Great question! Curiosity is the first step to staying safe online. \n\n";

            return "";
        }

        // Follow-up responses 
        private string GetFollowUp()
        {
            switch (lastTopic)
            {
                case "password": return GetRandom(passwordTips);
                case "phishing": return GetRandom(phishingTips);
                case "privacy": return Personalise(GetRandom(privacyTips));
                case "browsing": return BrowsingTips();
                case "malware": return MalwareTips();
                case "social engineering": return SocialEngineeringTips();
                case "2fa": return TwoFATips();
                default: return "Type a topic first — e.g. 'passwords', 'phishing', or 'malware'.";
            }
        }

        //  Personalise response using memory 
        private string Personalise(string tip)
        {
            if (!string.IsNullOrEmpty(favouriteTopic))
                return $"As someone interested in {favouriteTopic}: {tip}";
            return tip;
        }

        //  Topics menu 
        private string GetTopicsMenu() =>
            "Here's what I can help with:\n\n" +
            " Password           — Password safety\n" +
            " Phishing / scam    — Email scams\n" +
            " Browsing           — Safe browsing\n" +
            " Malware / virus    — Viruses & malware\n" +
            " Social engineering — Manipulation tactics\n" +
            " 2fa                — Two-factor auth\n" +
            " Privacy            — Protecting your data\n\n" +
            "You can also say:\n" +
            "• \"I'm interested in privacy\"\n" +
            "• \"Give me another tip\" / \"Tell me more\"";

        // Tip methods 
        private string BrowsingTips() =>
            "Safe browsing tips:\n\n" +
            "• Always check for 'https://' and the 🔒 padlock.\n" +
            "• Avoid public Wi-Fi for banking or sensitive tasks.\n" +
            "• Keep your browser updated.\n" +
            "• Fake virus pop-ups are usually scams — close them.\n" +
            "• Only download software from official sources.";

        private string MalwareTips() =>
            "Protecting yourself from malware:\n\n" +
            "• Install a reputable antivirus and keep it updated.\n" +
            "• Never open email attachments from unknown senders.\n" +
            "• Avoid pirated software — it often contains viruses.\n" +
            "• Back up your important files regularly.\n" +
            "• Keep your operating system updated.";

        private string SocialEngineeringTips() =>
            "Social engineering awareness:\n\n" +
            "• Vishing: Fake calls pretending to be your bank or SARS.\n" +
            "• Smishing: Fraudulent SMS messages with malicious links.\n" +
            "• NEVER share your OTP, PIN, or password — even with 'support'.\n" +
            "• Verify anyone asking for sensitive info.\n" +
            "• If something feels wrong, hang up or ignore the message.";

        private string TwoFATips() =>
            "Two-Factor Authentication (2FA):\n\n" +
            "• 2FA adds a second layer of security beyond your password.\n" +
            "• Even if your password is stolen, 2FA blocks the attacker.\n" +
            "• Use an app like Google Authenticator or Authy.\n" +
            "• Enable 2FA on your email, banking, and social media.\n" +
            "• Never share your OTP with anyone.";

        // Helpers 
        private string GetRandom(List<string> list) => list[rng.Next(list.Count)];

        private void PlayGreeting()
        {
            try
            {
                string[] paths = {
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "greeting.wav"),
                    @"C:\Users\itebo\source\repos\CyberSecurityBot prt2\CyberSecurityBot prt2\greeting.wav"
                };
                foreach (var p in paths)
                {
                    if (File.Exists(p)) { new SoundPlayer(p).Play(); break; }
                }
            }
            catch { }
        }

        // UI: add chat bubbles 
        private void AddBotMessage(string text)
        {
            var bubble = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(32, 44, 51)),
                CornerRadius = new CornerRadius(0, 12, 12, 12),
                Padding = new Thickness(10, 8, 10, 8),
                Margin = new Thickness(12, 3, 60, 2),
                MaxWidth = 290,
                HorizontalAlignment = HorizontalAlignment.Left
            };
            bubble.Child = new TextBlock
            {
                Text = text,
                Foreground = Brushes.WhiteSmoke,
                FontSize = 13,
                TextWrapping = TextWrapping.Wrap,
                LineHeight = 20
            };
            ChatPanel.Children.Add(bubble);
            AddTimestamp(HorizontalAlignment.Left, new Thickness(14, 0, 0, 6));
            ScrollToBottom();
        }

        private void AddUserMessage(string text)
        {
            var bubble = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(0, 92, 75)),
                CornerRadius = new CornerRadius(12, 0, 12, 12),
                Padding = new Thickness(10, 8, 10, 8),
                Margin = new Thickness(60, 3, 12, 2),
                MaxWidth = 290,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            bubble.Child = new TextBlock
            {
                Text = text,
                Foreground = Brushes.WhiteSmoke,
                FontSize = 13,
                TextWrapping = TextWrapping.Wrap,
                LineHeight = 20
            };
            ChatPanel.Children.Add(bubble);
            AddTimestamp(HorizontalAlignment.Right, new Thickness(0, 0, 14, 6));
            ScrollToBottom();
        }

        private void AddTimestamp(HorizontalAlignment align, Thickness margin)
        {
            ChatPanel.Children.Add(new TextBlock
            {
                Text = DateTime.Now.ToString("HH:mm"),
                Foreground = new SolidColorBrush(Color.FromRgb(134, 150, 160)),
                FontSize = 10,
                HorizontalAlignment = align,
                Margin = margin
            });
        }

        private void ScrollToBottom()
        {
            ChatScroller.UpdateLayout();
            ChatScroller.ScrollToEnd();
        }

        // Event handlers 
        private async void SendButton_Click(object sender, RoutedEventArgs e) => await Send();
        private async void UserInput_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) await Send(); }

        private async Task Send()
        {
            string input = UserInputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;

            UserInputBox.Clear();
            InputPlaceholder.Visibility = Visibility.Visible;
            AddUserMessage(input);

            BotStatus.Text = "typing...";
            await Task.Delay(600);

            AddBotMessage(GetResponse(input));
            BotStatus.Text = "Online";
        }

        private void UserInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            InputPlaceholder.Visibility = string.IsNullOrEmpty(UserInputBox.Text)
                ? Visibility.Visible : Visibility.Collapsed;
        }

        private void TopicsButton_Click(object sender, RoutedEventArgs e) => AddBotMessage(GetTopicsMenu());

    
    }
}
